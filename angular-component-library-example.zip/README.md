# README

##  Libreria Angular para la creación de un botón con unos atributos corporativos predeterminados
- Este repositorio incluye la librería y una aplicación _Demo_ para comprobar los resultados

### **Fuentes:**
- Es el resultado de seguir el tutorial de Jason White https://jasonwhite.xyz/posts/2020/04/16/creating-an-angular-component-library-workspace-setup/ 
- Repositorio del proyecto original: https://github.com/jmw5598/angular-component-library-example/tree/part1/start

#### **Una vez descargado el proyecto hacer:**
* _npm install_
* _npm run build_
