export enum ButtonShape {
  SQUARED = 'button-shape-squared',
  ROUNDED = 'button-shape-rounded',
  PILLED = 'button-shape-pilled'
}