export enum ButtonStyle {
  SOLID = "button-style-solid",
  OUTLINED = "button-style-outlined",
}